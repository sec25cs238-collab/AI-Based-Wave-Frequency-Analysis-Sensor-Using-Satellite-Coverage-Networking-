# OceanWave AI — Wave Frequency Monitoring Prototype

A runnable web prototype for **AI-Based Wave Frequency Analysis Sensor Using Satellite Coverage Networking**. It provides a live-style dashboard, simulated buoy measurements, wave frequency/period calculations, threshold-based alerts, simulated satellite connectivity, sample data, and CSV export.

> **Important:** This is a software demonstration. It does not connect to real ocean sensors or satellite services, and its threshold rules are not a trained AI model. Do not use it for navigation, weather warnings, or emergency decisions.

## Features
- Live simulated wave height, frequency, period, and water temperature.
- Automatic refresh every two seconds.
- Prototype anomaly alerts for high waves / high frequency.
- Simulated satellite connection status.
- Wave-height history chart.
- Bundled sample data and CSV download.
- Health endpoint and automated unit tests.
- Python standard library only; no API keys or paid services required.

## Requirements
- Python 3.9 or later
- A modern web browser

## Run locally
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python app.py
   ```
4. Open `http://127.0.0.1:8000` in your browser.
5. Stop the server with `Ctrl+C`.

To use another port:
```bash
# Windows PowerShell
$env:PORT=8080; python app.py

# macOS/Linux
PORT=8080 python app.py
```

## API endpoints
| Endpoint | Purpose |
|---|---|
| `/` | Dashboard |
| `/api/live` | New simulated reading, analysis, and recent history |
| `/api/samples` | Bundled CSV sample data as JSON |
| `/health` | Health check |

## Tests
Run from the repository root:
```bash
python -m unittest discover -s tests -v
```

## Architecture
See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Next steps for a real deployment
1. Connect a calibrated wave sensor to an ESP32/Raspberry Pi gateway.
2. Replace `generate_reading()` with authenticated sensor ingestion.
3. Add a real satellite/LoRa/GSM telemetry adapter and retry/buffering logic.
4. Validate thresholds against oceanographic data and domain experts.
5. Train and evaluate an ML model using labelled historical wave data before calling it AI prediction.
6. Add authentication, encryption, audit logs, secure deployment, and safety validation.

## Repository checklist
- [x] README and setup instructions
- [x] Technical architecture document
- [x] Sample data
- [x] Test cases
- [x] License file
- [x] Working local prototype
