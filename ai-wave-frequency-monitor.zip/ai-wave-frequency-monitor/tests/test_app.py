import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import app

class WavePrototypeTests(unittest.TestCase):
    def test_frequency_and_period_are_reciprocals(self):
        r = app.generate_reading(t=3.0)
        self.assertGreater(r["frequency_hz"], 0)
        self.assertAlmostEqual(r["period_s"], round(1 / r["frequency_hz"], 2), places=2)

    def test_high_wave_creates_alert(self):
        reading = {
            "wave_height_m": 2.1, "frequency_hz": 0.25,
            "satellite_connected": True
        }
        result = app.analyse(reading)
        self.assertEqual(result["status"], "ALERT")
        self.assertTrue(any(a["level"] == "HIGH" for a in result["alerts"]))

    def test_satellite_loss_creates_warning(self):
        reading = {
            "wave_height_m": 0.8, "frequency_hz": 0.24,
            "satellite_connected": False
        }
        result = app.analyse(reading)
        self.assertEqual(result["status"], "DEGRADED")
        self.assertTrue(any(a["level"] == "WARNING" for a in result["alerts"]))

    def test_sample_data_exists(self):
        samples = app.read_sample_data()
        self.assertGreaterEqual(len(samples), 5)
        self.assertIn("frequency_hz", samples[0])

if __name__ == "__main__":
    unittest.main()
