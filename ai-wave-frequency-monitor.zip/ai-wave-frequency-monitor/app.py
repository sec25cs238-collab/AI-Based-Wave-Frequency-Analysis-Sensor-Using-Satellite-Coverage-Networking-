"""AI-Based Wave Frequency Analysis Sensor - runnable prototype.

Uses Python's standard library only. Sensor readings and satellite connectivity
are simulated; this is a software prototype, not a live ocean instrument.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
import json, math, random, time, csv, os
from collections import deque

HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "8000"))
START = time.time()
HISTORY = deque(maxlen=120)
random.seed()

def generate_reading(t=None):
    """Generate a simulated buoy reading with occasional rough-wave events."""
    if t is None:
        t = time.time() - START
    rough = (int(t) % 47) in range(28, 35)
    period = 4.2 if not rough else 2.1
    amplitude = 0.75 if not rough else 2.35
    wave_height = max(0.05, amplitude + 0.18 * math.sin(t / 5) + random.uniform(-0.12, 0.12))
    # Estimated frequency is cycles/second (Hz), derived from wave period.
    frequency = round(1.0 / period + random.uniform(-0.008, 0.008), 3)
    temperature = 24.5 + 1.2 * math.sin(t / 70) + random.uniform(-0.2, 0.2)
    satellite_ok = random.random() > 0.035
    return {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "elapsed_s": round(t, 1),
        "wave_height_m": round(wave_height, 2),
        "frequency_hz": frequency,
        "period_s": round(1 / frequency, 2),
        "temperature_c": round(temperature, 1),
        "satellite_connected": satellite_ok,
        "wave_state": "ROUGH" if rough or wave_height >= 1.8 else "NORMAL"
    }

def analyse(reading, history=None):
    """Rule-based prototype alert logic; replace with trained model for deployment."""
    history = list(history or [])
    alerts = []
    if reading["wave_height_m"] >= 1.8 or reading["frequency_hz"] >= 0.40:
        alerts.append({"level": "HIGH", "message": "Abnormal wave conditions detected. Check marine safety guidance."})
    if not reading["satellite_connected"]:
        alerts.append({"level": "WARNING", "message": "Satellite link unavailable; data transmission may be delayed."})
    if not alerts:
        alerts.append({"level": "INFO", "message": "Wave conditions are within prototype thresholds."})
    return {
        "status": "ALERT" if any(a["level"] == "HIGH" for a in alerts) else (
            "DEGRADED" if any(a["level"] == "WARNING" for a in alerts) else "NORMAL"),
        "alerts": alerts,
        "method": "Prototype threshold analysis (not a trained AI model)"
    }

def snapshot():
    reading = generate_reading()
    HISTORY.append(reading)
    return {"reading": reading, "analysis": analyse(reading, HISTORY), "history": list(HISTORY)}

def read_sample_data():
    path = os.path.join(os.path.dirname(__file__), "data", "sample_wave_data.csv")
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OceanWave AI | Wave Monitor</title>
<style>
:root{--navy:#10243a;--blue:#176b87;--teal:#28a6a1;--bg:#f2f6f9;--ink:#193247;--muted:#657b8c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}
header{background:linear-gradient(120deg,#10243a,#176b87);color:white;padding:24px clamp(18px,5vw,60px)}
header h1{margin:0;font-size:clamp(24px,4vw,34px)}header p{margin:5px 0 0;color:#d5eaf1}
main{max-width:1180px;margin:24px auto;padding:0 18px}.notice{background:#fff8df;border:1px solid #f0d77b;border-radius:10px;padding:12px 15px;margin-bottom:18px;color:#705819}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.card{background:white;border:1px solid #e0e9ef;border-radius:14px;padding:18px;box-shadow:0 3px 12px #18354a0b}
.label{color:var(--muted);font-size:13px}.value{font-size:30px;font-weight:750;margin:7px 0 0}.unit{font-size:14px;font-weight:500;color:var(--muted)}
.row{display:grid;grid-template-columns:1.5fr 1fr;gap:14px;margin-top:14px}.card h2{font-size:17px;margin:0 0 12px}.chart{width:100%;height:220px;display:block;background:#f8fbfd;border-radius:8px}
.badge{display:inline-block;padding:5px 9px;border-radius:30px;font-weight:700;font-size:12px}.good{background:#dff7eb;color:#137247}.warn{background:#fff0ce;color:#8a5b00}.bad{background:#ffe0e0;color:#a12c2c}
#alerts{padding-left:18px;margin:0}#alerts li{margin:9px 0}.meta{color:var(--muted);font-size:13px}.controls{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}.btn{border:0;border-radius:9px;background:var(--blue);color:white;padding:10px 15px;font-weight:650;cursor:pointer}.btn.secondary{background:#e1edf2;color:#17445a}
table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;padding:8px;border-bottom:1px solid #e8eef2}footer{text-align:center;color:var(--muted);padding:24px;font-size:12px}
@media(max-width:800px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.row{grid-template-columns:1fr}.value{font-size:25px}}
</style></head>
<body><header><h1>🌊 OceanWave AI</h1><p>AI-Based Wave Frequency Analysis Sensor Using Satellite Coverage Networking</p></header>
<main>
<div class="notice"><strong>Prototype mode:</strong> readings and satellite connectivity are simulated. Do not use this dashboard for real navigation or emergency decisions.</div>
<div class="grid">
<div class="card"><div class="label">Wave frequency</div><div class="value" id="freq">-- <span class="unit">Hz</span></div></div>
<div class="card"><div class="label">Wave period</div><div class="value" id="period">-- <span class="unit">s</span></div></div>
<div class="card"><div class="label">Wave height</div><div class="value" id="height">-- <span class="unit">m</span></div></div>
<div class="card"><div class="label">Sea temperature</div><div class="value" id="temp">-- <span class="unit">°C</span></div></div>
</div>
<div class="row">
<section class="card"><h2>Recent wave readings</h2><canvas id="chart" class="chart" width="700" height="220" aria-label="Wave height chart"></canvas><div class="meta">Wave height (m) · refreshed every 2 seconds</div></section>
<section class="card"><h2>System status</h2><p><span id="status" class="badge good">CONNECTING</span></p><p>Satellite link: <strong id="sat">checking…</strong></p><p>Last update: <span id="stamp">--</span></p><hr style="border:0;border-top:1px solid #e8eef2"><h2>Alerts & analysis</h2><ul id="alerts"><li>Waiting for first reading…</li></ul><p class="meta" id="method"></p></section>
</div>
<div class="controls"><button class="btn" onclick="refresh()">Refresh reading</button><button class="btn secondary" onclick="downloadCsv()">Download current history CSV</button><button class="btn secondary" onclick="showSamples()">View sample data</button></div>
<section class="card" id="samples" hidden><h2>Bundled sample readings</h2><div style="overflow:auto"><table><thead><tr><th>Timestamp</th><th>Height (m)</th><th>Frequency (Hz)</th><th>Period (s)</th><th>State</th></tr></thead><tbody id="sampleRows"></tbody></table></div></section>
</main><footer>Educational software prototype · Standard-library Python backend · Satellite / sensor hardware not connected</footer>
<script>
let history=[];
async function refresh(){try{const r=await fetch('/api/live');const d=await r.json();const x=d.reading;history=d.history;
document.getElementById('freq').innerHTML=x.frequency_hz+' <span class="unit">Hz</span>';
document.getElementById('period').innerHTML=x.period_s+' <span class="unit">s</span>';
document.getElementById('height').innerHTML=x.wave_height_m+' <span class="unit">m</span>';
document.getElementById('temp').innerHTML=x.temperature_c+' <span class="unit">°C</span>';
document.getElementById('stamp').textContent=x.timestamp;
document.getElementById('sat').textContent=x.satellite_connected?'Connected (simulated)':'Disconnected (simulated)';
const s=document.getElementById('status');s.textContent=d.analysis.status;s.className='badge '+(d.analysis.status==='NORMAL'?'good':d.analysis.status==='DEGRADED'?'warn':'bad');
document.getElementById('alerts').innerHTML=d.analysis.alerts.map(a=>'<li><span class="badge '+(a.level==='HIGH'?'bad':a.level==='WARNING'?'warn':'good')+'">'+a.level+'</span> '+a.message+'</li>').join('');
document.getElementById('method').textContent=d.analysis.method;drawChart();
}catch(e){document.getElementById('sat').textContent='Backend unavailable';}}
function drawChart(){const c=document.getElementById('chart'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#dce7ed';ctx.lineWidth=1;
for(let i=0;i<5;i++){let y=15+i*(h-35)/4;ctx.beginPath();ctx.moveTo(35,y);ctx.lineTo(w-10,y);ctx.stroke();}
ctx.fillStyle='#657b8c';ctx.font='12px sans-serif';ctx.fillText('m',8,18);let vals=history.slice(-50).map(v=>v.wave_height_m);if(vals.length<2)return;
let max=Math.max(2.5,...vals);ctx.strokeStyle='#168b9c';ctx.lineWidth=3;ctx.beginPath();vals.forEach((v,i)=>{let x=35+i*(w-50)/(vals.length-1),y=h-20-v/max*(h-40);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.stroke();}
async function downloadCsv(){if(!history.length)await refresh();let rows=['timestamp,wave_height_m,frequency_hz,period_s,temperature_c,satellite_connected'];history.forEach(x=>rows.push([x.timestamp,x.wave_height_m,x.frequency_hz,x.period_s,x.temperature_c,x.satellite_connected].join(',')));let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([rows.join('\\n')],{type:'text/csv'}));a.download='wave-history.csv';a.click();URL.revokeObjectURL(a.href);}
async function showSamples(){let el=document.getElementById('samples');el.hidden=!el.hidden;if(!el.hidden){let r=await fetch('/api/samples'),d=await r.json();document.getElementById('sampleRows').innerHTML=d.map(x=>'<tr><td>'+x.timestamp+'</td><td>'+x.wave_height_m+'</td><td>'+x.frequency_hz+'</td><td>'+x.period_s+'</td><td>'+x.wave_state+'</td></tr>').join('');}}
refresh();setInterval(refresh,2000);
</script></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def _send(self, status, body, content_type="application/json; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._send(200, HTML, "text/html; charset=utf-8")
        elif path == "/api/live":
            self._send(200, json.dumps(snapshot()))
        elif path == "/api/samples":
            self._send(200, json.dumps(read_sample_data()))
        elif path == "/health":
            self._send(200, json.dumps({"status": "ok"}))
        else:
            self._send(404, json.dumps({"error": "Not found"}))

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

if __name__ == "__main__":
    print(f"OceanWave AI prototype running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop. Sensor and satellite data are simulated.")
    HTTPServer((HOST, PORT), Handler).serve_forever()
