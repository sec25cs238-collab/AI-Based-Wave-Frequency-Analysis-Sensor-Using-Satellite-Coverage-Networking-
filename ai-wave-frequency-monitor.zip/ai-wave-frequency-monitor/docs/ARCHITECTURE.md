# Technical Design and Architecture

## Purpose
Demonstrate the data flow for a wave-monitoring buoy that would report ocean conditions from remote areas through a satellite network.

## Current prototype flow
```text
Simulated buoy readings
        |
        v
Python reading generator
        |
        v
Frequency / period fields + threshold analysis
        |
        +------> Alert status and messages
        |
        v
JSON API (HTTP server)
        |
        v
Browser dashboard -> live cards, chart, CSV export
```

## Reading fields
- `timestamp`: local server time
- `wave_height_m`: simulated wave height in metres
- `frequency_hz`: estimated cycles per second
- `period_s`: reciprocal of frequency
- `temperature_c`: simulated water temperature
- `satellite_connected`: simulated link status
- `wave_state`: `NORMAL` or `ROUGH`

## Alert logic
The demonstration flags a high-level alert when wave height is at least 1.8 m or frequency is at least 0.40 Hz. A warning appears when the simulated satellite link is unavailable. These are example thresholds only and are not validated for real marine use.

## Suggested real-world architecture
```text
Wave sensor + IMU + GPS
        |
ESP32 / Raspberry Pi edge controller
        |
Timestamping, calibration, local buffer
        |
Satellite / LoRa / cellular modem
        |
Secure cloud ingestion endpoint
        |
Validated signal processing + evaluated ML model
        |
Time-series database -> dashboard -> notification service
```

## Reliability and safety considerations
- Use sensor calibration and time synchronization.
- Buffer readings during communication outages and resend safely.
- Secure device identity and encrypt data in transit.
- Monitor battery, sensor health, corrosion, and sensor fouling.
- Validate alerts against labelled observations and expert guidance.
- Provide explicit uncertainty and never present a prototype alert as an official warning.
